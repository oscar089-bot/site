Investorm - Advanced HYIP Investment Management Platform @by Softnio.
--------------------------------------------------------------------------

All the files are in this folder are related for manual install and it not require for Nio Laravel Installer.

#######################################################
####   IF you go through Default / Manual Install  ####
#######################################################

> First of public the files into your server as per below structure. 
  Ensure that /public or public_html folder and core_invapp folder should consider as siblings.

  |---root
  |---|---core_invapp
  |---|---public (public_html)
  |---|---|---index.php

> Then update the '.env' file from 'core_invapp' folder according to your information. 
  APP_NAME, APP_URL, DB_HOST, DB_DATABASE, DB_USERNAME, DB_PASSWORD

> Must update your folder permission as per documentation. 

> You will need to copy the 'installed' file and placed into 'core_invapp/storage' folder.

> Import the 'dummy_app.sql' into your database for demo data. 

> Once above complete, please go to your website url and setup your Super Admin account.

--------------------------------------------------------------------------
|
|  .htaccess 
|  
|  - this file may require you if face problem  
|    to open website for 'mod_rewrite' rules. 
|
|  ^ Caution: It's already in /public or /public_html folder but sometimes
|    you may need if you update PHP version for install application. 
|
--------------------------------------------------------------------------

Thanks for choose our product.
Softnio Team.